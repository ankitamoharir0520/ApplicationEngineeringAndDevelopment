/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Ankita
 */
public class VitalSignHistory {
 
    private Iterable<VitalSigns> vitalSignList;
    private ArrayList<VitalSigns> vitalSignHistory;

    public ArrayList<VitalSigns> getVitalSignHistory() {
        return vitalSignHistory;
    }
    
    public VitalSignHistory()
    {
        vitalSignHistory = new ArrayList<VitalSigns>();
    }

    public void setVitalSignHistory(ArrayList<VitalSigns> vitalSignHistory) {
        this.vitalSignHistory = vitalSignHistory;
    }
    
    
    public VitalSigns addVitals(){
        VitalSigns vs = new VitalSigns();
        vitalSignHistory.add(vs);
        return vs;
    }
    
    public void deleteVitals(VitalSigns v){
        vitalSignHistory.remove(v);
    }
    
    public ArrayList<VitalSigns> getVitalSignList(){
        VitalSigns vs = new VitalSigns();
        return vitalSignHistory;
    }
//        
//        for(VitalSigns vsh:vitalSignList)
//        {
//            if(vs.getBloodPressure()>70 || vs.getBloodPressure()<100)
//            {
//                vsh.add(vs);
//            }
//            if(vs.getHeartRate()>70 || vs.getHeartRate()<100)
//            {
//                abnList.add(vs);
//            }
//            if(vs.getRespiratoryRate()>70 || vs.getRespiratoryRate()<100)
//            {
//                abnList.add(vs);
//            }
//            if(vs.getWeightKilos()>40 || vs.getWeightKilos()<90)
//            {
//                abnList.add(vs);
//            }
//            if(vs.getWeightPounds()>100 || vs.getWeightPounds()<200)
//            {
//                abnList.add(vs);
//            }
//        }   
//        return abnList;
//    }
}
