/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;

/**
 *
 * @author Ankita
 */
public class PatientHistory {

    private ArrayList<Patient> ph;
    
    
     public PatientHistory()
    {
        ph = new ArrayList<Patient>();
    }

    public ArrayList<Patient> getPh() {
        return ph;
    }

    public void setPh(ArrayList<Patient> ph) {
        this.ph = ph;
    }
    
    public Patient addPatients(){
        Patient p = new Patient();
        ph.add(p);
        return p;
    }
    
    public void deletePatients(Patient p){
        ph.remove(p);
    }
    
   
}
