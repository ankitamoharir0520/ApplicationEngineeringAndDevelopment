/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import Business.Patient;
import Business.VitalSigns;
import java.awt.Color;
import java.awt.Component;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

/**
 *
 * @author Ankita
 */
public class IsAbnormal extends DefaultTableCellRenderer {
    private VitalSignHistory vsh;
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        Component cell = super.getTableCellRendererComponent(
                            table, value, isSelected, hasFocus, row, column);
        
        VitalSigns vs = new VitalSigns();
        
        if (vs.getHeartRate() >70 || vs.getHeartRate()<100) 
        { // Cell selected
           cell.setForeground(Color.red);
        }return cell;
    } 
}

    
