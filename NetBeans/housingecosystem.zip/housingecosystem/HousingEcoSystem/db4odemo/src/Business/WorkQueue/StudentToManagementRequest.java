/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.WorkQueue;

/**
 *
 * @author Nikita
 */
public class StudentToManagementRequest {
    private String SendStudentDetails;

    public String getSendStudentDetails() {
        return SendStudentDetails;
    }

    public void setSendStudentDetails(String SendStudentDetails) {
        this.SendStudentDetails = SendStudentDetails;
    }
}
