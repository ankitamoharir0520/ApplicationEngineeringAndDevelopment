 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.List;
import java.util.ArrayList;

/**
 *
 * @author Ankita
 */
public class VitalSignHistory {

    private Iterable<VitalSigns> vitalSignList;
    private ArrayList<VitalSigns> vitalSignHistory;

    public ArrayList<VitalSigns> getVitalSignHistory() {
        return vitalSignHistory;
    }
    
    public VitalSignHistory()
    {
        vitalSignHistory = new ArrayList<VitalSigns>();
    }

    public void setVitalSignHistory(ArrayList<VitalSigns> vitalSignHistory) {
        this.vitalSignHistory = vitalSignHistory;
    }
    
    
    public VitalSigns addVitals(){
        VitalSigns vs = new VitalSigns();
        vitalSignHistory.add(vs);
        return vs;
    }
    
    public void deleteVitals(VitalSigns v){
        vitalSignHistory.remove(v);
    }
    
    public ArrayList<VitalSigns> getVitalSignList(){
        VitalSigns vs = new VitalSigns();
        return vitalSignHistory;
    }
    public List<VitalSigns> getAbnormalList(double maxBp, double minBp)
    {
        List<VitalSigns> abnList = new ArrayList<>();
        
        for(VitalSigns vs:vitalSignHistory)
        {
            if(vs.getBloodPressure()>maxBp || vs.getBloodPressure()<minBp)
            {
                abnList.add(vs);
            }
        }   
        return abnList;
    }
}
